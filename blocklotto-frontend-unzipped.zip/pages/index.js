
import { ConnectButton } from '@rainbow-me/rainbowkit';
import '@rainbow-me/rainbowkit/styles.css';
import { getDefaultWallets, RainbowKitProvider } from '@rainbow-me/rainbowkit';
import { configureChains, createClient, WagmiConfig } from 'wagmi';
import { polygonMumbai } from 'wagmi/chains';
import { publicProvider } from 'wagmi/providers/public';

const { chains, provider } = configureChains(
  [polygonMumbai],
  [publicProvider()]
);

const { connectors } = getDefaultWallets({
  appName: 'BlockLotto',
  chains,
});

const wagmiClient = createClient({
  autoConnect: true,
  connectors,
  provider
});

export default function Home() {
  return (
    <WagmiConfig client={wagmiClient}>
      <RainbowKitProvider chains={chains}>
        <main style={{ padding: 50 }}>
          <h1>BlockLotto</h1>
          <p>A Web3-powered Lottery System</p>
          <ConnectButton />
        </main>
      </RainbowKitProvider>
    </WagmiConfig>
  );
}
